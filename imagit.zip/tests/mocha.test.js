describe("Mocha", function() {
    describe("First Test", function() {
        it("should assert 1 equals 1", function() {
            expect(1).to.equal(1);
        });
    });
});